<?php 
$connect = mysqli_connect('localhost', 'root', '','gadgetzc_maindb');
?>