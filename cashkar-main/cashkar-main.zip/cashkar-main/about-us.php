<br>
 <div class="container" id="about">
               <div class="abt-1">
                  
                  <h2 style="font-size:30px;font-weight:500;" class="text-center pl-2">
                     Cash Kar - Sell Old Phone Online
                     </h2>
                     <hr>
                  <div class="abt-content">
                     <p>
                         Sell your old phone at Cash Kar and get the best value for your old mobile phone. For those who love buying new phones, but don't know what and how to sell off the old mobile device. Cash Kar is the answer to most of your questions related to your old mobile phone. You can check the price and be aware of how much money is your old mobile worth and according to that, you can decide on your new phone that fits the budget. Cash Kar provides instant cash, free mobile pick-up service, and a hassle-free experience along with the best price for your old phone. Before selling your old phone online, try Cash Kar. Our end goal is to provide the best value and seamless service to all our customers. Now selling your phone is just a tap away. Best price for used phones, quick service, hassle-free selling. What else are you waiting for? Purana Bech, Cash kar!
                     </p>
                  </div>
                  
               </div>
            </div>
            <br>